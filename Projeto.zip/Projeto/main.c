#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>

/*Opera��es com Inteiros*/
/*Soma*/
int SomaInt (int int1, int int2)
{
    int soma;
    soma = int1 + int2;
    return soma;
}

/*Subtra��o*/
int SubInt (int int1, int int2)
{
    int subtracao;
    subtracao = int1 - int2;
    return subtracao;
}

/*Multiplica��o*/
int MultInt (int int1, int int2)
{
    int multiplicacao;
    multiplicacao = int1 * int2;
    return multiplicacao;
}

/*Divis�o*/
int DivInt (int int1, int int2)
{
    int divisao;
    divisao = int1 / int2;
    return divisao;
}

/*Potencializa��o*/
int PotInt (int int1, int int2)
{
    int potencia;
    potencia = int1 ** int2;
    return potencia;
}

/*Resto da Divis�o*/
int RestoInt (int int1, int int2)
{
    int resto;
    resto = int1 % int2;
    return resto;
}

/*Opera��es com Reais*/
/*Soma*/
float SomaRe(float flt1, float nflt2)
{
    float soma;
    soma = flt1 + flt2;
    return soma;
}

/*Subtra��o*/
float SubRe (float flt1, float flt2)
{
    float subtracao;
    subtracao= flt1 - flt2;
    return subtracao;
}

/*Multiplica��o*/
float MultiRe (float flt1, float flt2)
{
    float multiplicacao;
    multiplicacao= flt1 * flt2;
    return multiplicacao;
}

/*Divis�o*/
float DivRe (float flt1, float flt2)
{
    float divisao;
    divisao= flt1 / flt2;
    return divisao;
}

/*Potencializa��o*/
float PotRe (float flt1, float flt2)
{
    float potencia;
    potencia = pow(flt1, flt2);
    return potencia;
}

/*Opera��o com Fra��es*/
typedef struct {
    int numerador, denominador;
}fracao;

/*MDC (Algoritmo de Euclides)*/
int MDC (fracao f1, fracao f2)
{
    int resto;
    resto=f1.denominador%f2.denominador;
    while(resto!=0)
    {
        f1.denominador = f2.denominador;
        f2.denominador = resto;
        resto = f1.denominador%f2.denominador;
    }
    return resto;
}

/*MMC (A partir do fun��o MDC)*/
int MMC (fracao f1, fracao f2)
{
    int mmc;
    mmc = (f1.denominador*f2.denominador)/MDC(f1,f2);
    return minimo;
}

/*Soma*/
fracao SomaFrac(fracao f1, fracao f2)
{
    fracao soma;
    if (f1.denominador == f2.denominador)
    {
        soma.denominador = f1.denominador;
        soma.numerador = f1.numerador + f2.numerador;
    }
    else
    {
        soma.denominador = MMC(f1,f2);
        soma.denominador = f1.numerador*f2.denominador + f2.numerador*f1.denominador;
    }
    return soma;
    }
}

/*Subtra��o*/
fracao SubFrac(fracao f1, fracao f2)
{
    fracao subtracao;
    if (f1.denominador == f2.denominador)
    {
        subtracao.denominador = f1.denominador;
        subtracao.numerador = f1.numerador - f2.numerador;
    }
    else
    {
        subtracao.denominador = MMC(f1,f2);
        subtracao.denominador = f1.numerador*f2.denominador - f2.numerador*f1.denominador;
    }
    return subtracao;
    }
}

/*Multiplica��o*/
fracao MultFrac(fracao f1, fracao f2)
{
    fracao multiplicacao;
    multiplicacao.numerador = f1.numerador * f2.numerador;
    multiplicacao.denominador = f1.denominador * f2.denominador;
    return multiplicacao;
}

/*Potencializa��o*/
fracao PotFrac(fracao f1, fracao f2)
{
    fracao potencia;
    potencia.numerador = pow(f1)
}

/*Divis�o*/
fracao DivFrac(fracao f1, fracao f2)
{
    fracao divisao;
    divisao.numerador = f1.numerador * f2.denominador;
    divisao.denominador = f1.denominador * f2.numerador;
    return divisao;
}

/*Opera��es com Complexos*/
typedef struct{
    double real,imaginario;
} complexo;

/*Soma*/
complexo SomaComp(complexo c1, complexo c2)
{
    complexo soma;
    soma.real= c1.real + c2.real;
    soma.imaginario = c1.imaginario + c2.imaginario;
    return soma;
}

/*Subtra��o*/
complexo SubComp(complexo c1, complexo c2)
{
    complexo subtracao;
    subtracao.real= c1.real - c2.real;
    subtracao.imaginario = c1.imaginario - c2.imaginario;

    return sub;
}

/*Multiplica��o*/
complexo MultCom(complexo c1, complexo c2)
{
    complexo multiplicacao;
    multiplicacao.real=0;
    multiplicacao.imaginario =0;

    if(c1.imaginario && c2.imaginario !=0)
    {
        multiplicacao.real = (-1)*c1.imaginario*c2.imaginario;
    }
    multiplicacao.real = multiplicacao.real + c1.real*c2.real;
    multiplicacao.imaginario = c1.real*c2.imaginario+c2.real*c1.imaginario;

    return multiplicacao;
}


int main()
{
    char tipo, oper;
    int int1, int2, resultado;
    float flt1, flt2, resultado;
    fracao f1, f2, resultado;
    complexo c1,c2,resultado;

    printf("\t\t\t    CALCULADORA CIENTIFICA\n\n");
    printf("Tipos de Operandos:\n");
    printf("'I' : Numeros Inteiros\n");
    printf("'F' : Fracoes\n")
    printf("'R' : Numeros Reais\n");
    printf("'C' : Numeros Complexos\n");
    printf("'M' : Matrizes\n\n");

    printf("\nOperacoes dispon�veis:\n");
    printf("'+' : soma\n");
    printf("'-' : subtracao\n");
    printf("'*' : multiplicao\n");
    printf("'/' : divisao\n");
    printf("'**' : potencializacao");
    printf("'%%' : resto da divisao\n\n");

    printf("Digite o Tipo dos Operandos que voce deseja utilizar:  ");
    scanf("%c", &tipo);
m nnn
    switch (tipo)
    {
        case 'I':
             printf("\nOperacoes dispon�veis:\n");
             printf("'+' : soma\n");
             printf("'*' : multiplicao\n");
             printf("'/' : divisao\n");
             printf("'**' : potencializacao");
             printf("'%%' : resto da divisao\n\n");

             printf("\n\nDigite o Operando 1: ");
             scanf("%d", &int1);
             printf("\nDigite o Operando 2: ");
             scanf("%d", &int2);


             printf("Digite a Operacao que voce deseja utilizar:  ");
             scanf("%c", &oper);


             switch (oper)
             {
                 case '+':
                     resultado = SomaInt(int1, int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '-':
                     resultado = SubInt(int1,int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '*':
                     resultado = MultInt(int1,int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '\\':
                     resultado = DivInt(int1,int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '**':
                     resultado = PotInt(int1, int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '%':
                     resultado = RestoInt(int1, int2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 default:
                        printf("Comando Invalido\n");
            }

        case 'F':
             printf("\nOperacoes dispon�veis:\n");
             printf("'+' : soma\n");
             printf("'-' : subtracao\n");
             printf("'*' : multiplicao\n");
             printf("'/' : divisao\n");
             printf("'**' : potencializacao");

             printf("Digite o numerador da primeira fracao (Operando 1): ");
             scanf("%d", &f1.numerador);
             printf("Digite o denominador da primeira fracao (Operando 1): ");
             scanf("%d", &f1.denominador);
             printf("Digite o numerador da segunda fracao (Operando 2): ");
             scanf("%d", &f2.numerador);
             printf("Digite o denominador da segunda fracao (Operando 2): ");
             scanf("%d", &f2.denominador);
             if(f1.denominador && f2.denominador == 0)
             {
                 printf("Valor impossivel");
             }
             else
             {
                  printf("Digite a Operacao que voce deseja utilizar:  ");
                  scanf("%c", &oper);
             }

              switch (oper)
             {
                 case '+':
                     resultado = SomaFrac(f1,f2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '-':
                     resultado = SubFrac(f1,f2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '*':
                     resultado = MultFrac(f1,f2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '\\':
                     resultado = DivFrac(f1,f2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '**':
                     resultado = PotFrac(f1,f2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 default:
                        printf("Comando Invalido\n");
            }

        case 'R':
             printf("\nOperacoes dispon�veis:\n");
             printf("'+' : soma\n");
             printf("'*' : multiplicao\n");
             printf("'/' : divisao\n");
             printf("'**' : potencializacao");

             printf("\n\nDigite o Operando 1: ");
             scanf("%d", &ftl1);
             printf("\nDigite o Operando 2: ");
             scanf("%d", &ftl2);


             printf("Digite a Operacao que voce deseja utilizar:  ");
             scanf("%c", &oper);


             switch (oper)
             {
                 case '+':
                     resultado = SomaRe(ftl1, ftl2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '-':
                     resultado = SubRe(ftl1,ftl2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '*':
                     resultado = MultRe(ftl1,ftl2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '\\':
                     resultado = DivRe(ftl1,ftl2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '**':
                     resultado = PotRe(ftl1, ftl2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 default:
                        printf("Comando Invalido\n");
            }

        case 'C':
             printf("\nOperacoes dispon�veis:\n");
             printf("'+' : soma\n");
             printf("'*' : multiplicao\n");
             printf("'/' : divisao\n");
             printf("'**' : potencializacao");

             printf("\n\nDigite o Operando 1: ");
             scanf("%d", &c1);
             printf("\nDigite o Operando 2: ");
             scanf("%d", &c2);


             printf("Digite a Operacao que voce deseja utilizar:  ");
             scanf("%c", &oper);


             switch (oper)
             {
                 case '+':
                     resultado = SomaComp(c1, c2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '-':
                     resultado = SubComp(c1,c2);
                     printf("O Resultado eh %d", resultado);
                     break;

                 case '*':
                     resultado = MultComp(c1,cl2);
                     printf("O Resultado eh %d", resultado);
                     break;






                 default:
                        printf("Comando Invalido\n");
            }


    return 0;
}
